<template>
  <v-container class="my-12 py-12">
    <v-row>
      <v-col cols="12" align="center" justify="center">
        <span class="display-4">404</span>
      </v-col>
    </v-row>
    <v-row>
      <v-col align="center" justify="center">
        <span class="display-4">Page Not Found!</span>
      </v-col>
    </v-row>
    
  </v-container>
</template>

<script>
  export default {
    name: 'PageNotFound',

    data: () => ({
      
    }),
  }
</script>
