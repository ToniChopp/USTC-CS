from flask import Flask

# app instance
app = Flask(__name__)


