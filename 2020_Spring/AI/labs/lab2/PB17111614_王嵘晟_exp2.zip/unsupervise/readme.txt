代码编写环境： python 3.7.6
运行方式： 命令行输入
python main.py